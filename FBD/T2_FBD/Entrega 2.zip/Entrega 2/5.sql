SELECT
COUNT(ea.empreendimento_id) AS numberAccess,
ep.dormitorios as dormitorios
FROM public.empreendimento emp
INNER JOIN public.empreendimento_planta ep
 ON ep.empreendimento_id = emp.id
INNER JOIN public.empreendimento_acessos ea
 ON ea.empreendimento_id = emp.id
WHERE ep.dormitorios > 0
GROUP BY dormitorios
ORDER BY numberAccess DESC;