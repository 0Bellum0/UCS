--Por Bairro

SELECT 
distinct e.id as empreendimento, 
b.nome as bairro, 
COUNT(ea.empreendimento_id) AS total_acessos
FROM empreendimento e
INNER JOIN empreendimento_acessos ea 
 ON e.id = ea.empreendimento_id
INNER JOIN bairro b 
 ON e.bairro_id = b.id
GROUP BY e.id, b.nome
ORDER BY total_acessos DESC;
 

--Por Cidade

SELECT 
e.id as empreendimento, 
c.nome as cidade, 
COUNT(*) AS total_acessos
FROM empreendimento e
INNER JOIN empreendimento_acessos ea 
    ON e.id = ea.empreendimento_id
INNER JOIN cidade c 
    ON e.cidade_id = c.id
GROUP BY e.id, c.nome
ORDER BY total_acessos DESC;

--Por Corretor

SELECT 
ea.empreendimento_id as empreendimento, 
c.id as corretor, 
COUNT(ea.user_id) AS total_acessos
FROM empreendimento_acessos ea 
INNER JOIN corretor c 
    ON ea.user_id = c.id
GROUP BY empreendimento, corretor
ORDER BY total_acessos DESC