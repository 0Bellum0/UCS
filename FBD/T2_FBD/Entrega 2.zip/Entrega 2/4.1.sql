SELECT 
b.nome AS bairro_nome, 
c.nome AS cidade_nome,
max(ep.valor / ep.area_total) AS valor_total
FROM bairro b
INNER JOIN empreendimento e 
 ON b.id = e.bairro_id
INNER JOIN empreendimento_tabela_venda ep 
 ON e.id = ep.empreendimento_id
INNER JOIN cidade c
 ON c.id = e.cidade_id
WHERE ep.valor > 0 AND ep.area_total > 0
GROUP BY bairro_nome, cidade_nome
ORDER BY valor_total DESC