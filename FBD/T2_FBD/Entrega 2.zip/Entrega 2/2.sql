SELECT 
ues.enterprise_id, 
COUNT(c.user_id) as total 
FROM user_enterprise_share as ues
INNER JOIN corretor as c
 ON c.user_id = ues.user_id
INNER JOIN empreendimento AS emp
 ON emp.id = ues.enterprise_id
INNER JOIN cidade AS cid
 ON cid.ID = emp.cidade_id
WHERE c.user_id = 214 AND cid.nome = 'Torres'
GROUP BY ues.enterprise_id
ORDER BY total DESC;