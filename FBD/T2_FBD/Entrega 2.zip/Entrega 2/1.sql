SELECT 
eps.posicao AS posicao_solar,
COUNT(emac.empreendimento_id) AS total_buscas
FROM public.empreendimento_acessos emac
INNER JOIN public.empreendimento e
	ON e.id = emac.empreendimento_id
INNER JOIN empreendimento_planta ep
	ON e.id = ep.empreendimento_id
INNER JOIN empreendimento_planta_posicao_solar eps
	ON eps.empreendimento_planta_id = ep.id
INNER JOIN bairro b
	ON e.bairro_id = b.id 
INNER JOIN cidade c 
	ON e.cidade_id = c.id
WHERE c.nome = 'Caxias do Sul' 
	AND b.nome = 'Centro'
GROUP BY eps.posicao
ORDER BY total_buscas DESC;